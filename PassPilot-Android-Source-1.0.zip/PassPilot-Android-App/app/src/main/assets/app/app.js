'use strict';

const APP_VERSION = '1.1.0-test';
const STORAGE_KEY = 'passpilot-state-v2';
const LEGACY_STORAGE_KEY = 'passpilot-state-v1';
const DB_NAME = 'passpilot-files-v1';
const DB_VERSION = 1;
const FILE_STORE = 'files';

const categoryMeta = {
  ebike: ['E-Bike / Fahrrad', '🚲'],
  electronics: ['Elektronik', '💻'],
  appliance: ['Haushaltsgerät', '🧺'],
  tool: ['Werkzeug', '🛠️'],
  camera: ['Kamera', '📷'],
  instrument: ['Instrument', '🎸'],
  other: ['Sonstiges', '📦']
};

let currentView = 'dashboard';
let toastTimer = null;
let deferredInstallPrompt = null;
const state = loadState();

function defaultState() {
  return {
    version: 3,
    settings: { ownerAlias: '', publicBaseUrl: '', introSeen: false, demoMode: false },
    products: []
  };
}

function normalizeProduct(p) {
  return {
    id: p.id || uid('prod'),
    createdAt: p.createdAt || new Date().toISOString(),
    category: p.category || 'other',
    name: p.name || '', brand: p.brand || '', model: p.model || '', serial: p.serial || '',
    location: p.location || '', purchaseDate: p.purchaseDate || '', retailer: p.retailer || '',
    price: p.price ?? '', currency: p.currency || 'EUR', returnUntil: p.returnUntil || '',
    warrantyUntil: p.warrantyUntil || '', nextMaintenance: p.nextMaintenance || '',
    notes: p.notes || '', publicNote: p.publicNote || '', coverImage: p.coverImage || '',
    status: ['active','lost','sale'].includes(p.status) ? p.status : 'active',
    publicSettings: { serial: p.publicSettings?.serial !== false, purchaseDate: Boolean(p.publicSettings?.purchaseDate) },
    history: Array.isArray(p.history) ? p.history : [],
    documents: Array.isArray(p.documents) ? p.documents : [],
    isDemo: Boolean(p.isDemo)
  };
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    const out = defaultState();
    out.settings = { ...out.settings, ...(parsed.settings || {}) };
    if(parsed.version < 3 && out.settings.introSeen == null) out.settings.introSeen = false;
    if(out.settings.demoMode == null) out.settings.demoMode = false;
    out.products = Array.isArray(parsed.products) ? parsed.products.map(normalizeProduct) : [];
    return out;
  } catch (err) {
    console.warn('State konnte nicht geladen werden:', err);
    return defaultState();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function uid(prefix='id') {
  if (globalThis.crypto?.randomUUID) return `${prefix}_${crypto.randomUUID()}`;
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

function esc(value='') {
  return String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
}

function formatDate(date) {
  if (!date) return '—';
  const d = new Date(`${date}T12:00:00`);
  return Number.isNaN(d.getTime()) ? date : new Intl.DateTimeFormat('de-DE').format(d);
}

function formatMoney(value, currency='EUR') {
  if (value === '' || value == null || Number.isNaN(Number(value))) return '—';
  try { return new Intl.NumberFormat('de-DE',{style:'currency',currency}).format(Number(value)); }
  catch { return `${value} ${currency}`; }
}

function daysUntil(date) {
  if (!date) return null;
  const now = new Date(); now.setHours(0,0,0,0);
  const target = new Date(`${date}T00:00:00`);
  if (Number.isNaN(target.getTime())) return null;
  return Math.ceil((target-now)/86400000);
}

function productTitle(p) { return p.name?.trim() || [p.brand,p.model].filter(Boolean).join(' ') || 'Unbenanntes Produkt'; }
function categoryLabel(key) { return categoryMeta[key]?.[0] || categoryMeta.other[0]; }
function categoryIcon(key) { return categoryMeta[key]?.[1] || categoryMeta.other[1]; }
function getProduct(id) { return state.products.find(p=>p.id===id); }

function statusBadge(status) {
  if (status === 'lost') return '<span class="badge danger">🚨 Verloren</span>';
  if (status === 'sale') return '<span class="badge warn">🏷 Verkauf</span>';
  return '<span class="badge good">● Aktiv</span>';
}

function deadlineBadge(date, horizon=30) {
  const d = daysUntil(date);
  if (d == null || d > horizon) return '';
  if (d < 0) return `<span class="badge danger">${Math.abs(d)} Tage überfällig</span>`;
  const kind = d<=3 ? 'danger' : d<=14 ? 'warn' : 'neutral';
  return `<span class="badge ${kind}">${d===0?'heute':`${d} Tage`}</span>`;
}

function openDb() {
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{ const db=req.result; if(!db.objectStoreNames.contains(FILE_STORE)) db.createObjectStore(FILE_STORE,{keyPath:'key'}); };
    req.onsuccess=()=>resolve(req.result); req.onerror=()=>reject(req.error);
  });
}

async function putFile(productId, docId, file) {
  const db=await openDb();
  return new Promise((resolve,reject)=>{ const tx=db.transaction(FILE_STORE,'readwrite'); tx.objectStore(FILE_STORE).put({key:`${productId}:${docId}`,productId,docId,blob:file}); tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error); });
}

async function getFile(productId, docId) {
  const db=await openDb();
  return new Promise((resolve,reject)=>{ const tx=db.transaction(FILE_STORE,'readonly'); const req=tx.objectStore(FILE_STORE).get(`${productId}:${docId}`); req.onsuccess=()=>resolve(req.result?.blob||null); req.onerror=()=>reject(req.error); });
}

async function deleteFile(productId, docId) {
  const db=await openDb();
  return new Promise((resolve,reject)=>{ const tx=db.transaction(FILE_STORE,'readwrite'); tx.objectStore(FILE_STORE).delete(`${productId}:${docId}`); tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error); });
}

function blobToDataUrl(blob) {
  return new Promise((resolve,reject)=>{ const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=reject; r.readAsDataURL(blob); });
}

function dataUrlToBlob(dataUrl) {
  const [head,data]=dataUrl.split(',');
  const mime=head.match(/data:(.*?);base64/)?.[1]||'application/octet-stream';
  const binary=atob(data); const bytes=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
  return new Blob([bytes],{type:mime});
}

async function getProductFiles(productId, shareOnly=false) {
  const p=getProduct(productId); if(!p) return [];
  const docs=(p.documents||[]).filter(d=>!shareOnly||d.share);
  const rows=[];
  for(const doc of docs){ const blob=await getFile(productId,doc.id); if(blob) rows.push({productId,doc,data:await blobToDataUrl(blob)}); }
  return rows;
}

function toast(message) {
  const el=document.getElementById('toast'); el.textContent=message; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),2400);
}

function modal(content) {
  const d=document.getElementById('modal'); d.innerHTML=`<div class="modal-inner">${content}</div>`;
  if(!d.open) d.showModal();
}
function closeModal(){ const d=document.getElementById('modal'); if(d.open)d.close(); }
function setNav(view){ document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===view)); }

function getActions() {
  const actions=[];
  for(const p of state.products){
    const rd=daysUntil(p.returnUntil);
    if(rd!=null&&rd>=0&&rd<=30) actions.push({productId:p.id,kind:rd<=3?'danger':'warn',icon:'↩️',title:rd===0?'Rückgabefrist endet heute':`Rückgabefrist in ${rd} Tagen`,detail:productTitle(p),date:p.returnUntil});
    const wd=daysUntil(p.warrantyUntil);
    if(wd!=null&&wd>=0&&wd<=90) actions.push({productId:p.id,kind:wd<=14?'warn':'neutral',icon:'🛡️',title:wd===0?'Garantie endet heute':`Garantie endet in ${wd} Tagen`,detail:productTitle(p),date:p.warrantyUntil});
    const md=daysUntil(p.nextMaintenance);
    if(md!=null&&md<=30) actions.push({productId:p.id,kind:md<0?'danger':md<=7?'warn':'neutral',icon:'🔧',title:md<0?`Wartung seit ${Math.abs(md)} Tagen fällig`:md===0?'Wartung heute fällig':`Wartung in ${md} Tagen`,detail:productTitle(p),date:p.nextMaintenance});
    if(p.status==='lost') actions.push({productId:p.id,kind:'danger',icon:'🚨',title:'Als verloren markiert',detail:productTitle(p),date:''});
    if(!p.serial&&['ebike','electronics','tool','camera','instrument'].includes(p.category)) actions.push({productId:p.id,kind:'neutral',icon:'🔢',title:'Seriennummer ergänzen',detail:productTitle(p),date:'9998-01-01'});
  }
  return actions.sort((a,b)=>(a.date||'9999').localeCompare(b.date||'9999'));
}

function render() {
  if(location.hash.startsWith('#pass=')){ renderPublicPass(location.hash.slice(6)); return; }
  const app=document.getElementById('app'); setNav(currentView);
  document.body.classList.toggle('demo-mode', Boolean(state.settings.demoMode));
  if(currentView==='products') app.innerHTML=productsView();
  else if(currentView==='actions') app.innerHTML=actionsView();
  else if(currentView==='backup') app.innerHTML=backupView();
  else app.innerHTML=dashboardView();
  if(state.settings.demoMode && !document.getElementById('demoBanner')){
    app.insertAdjacentHTML('afterbegin', demoBanner());
  }
}

function demoBanner(){
  return `<section id="demoBanner" class="demo-banner"><div><strong>Demo-Modus aktiv</strong><small>Du schaust dir Beispieldaten an. Du kannst den Demo-Modus jederzeit beenden.</small></div><div class="demo-actions"><button class="soft-btn" data-action="intro">Einführung</button><button class="ghost-btn" data-action="exit-demo">Demo beenden</button></div></section>`;
}

function introModal(){
  return `<div class="modal-head"><div><div class="eyebrow">In 60 Sekunden startklar</div><h2>Willkommen bei PassPilot</h2></div><button class="icon-btn" data-action="close-modal">✕</button></div>
  <div class="intro-hero intro-hero-premium">
    <div class="intro-mark">P</div>
    <div><strong>Alles Wichtige zu deinen Dingen an einem Ort.</strong><p>Rechnung, Garantie, Wartung, QR-Pass und Übergabe – übersichtlich und zunächst komplett lokal auf deinem Gerät.</p></div>
  </div>
  <div class="intro-steps">
    <div class="intro-step"><span>1</span><div><strong>Produkt erfassen</strong><small>Foto, Kaufdatum, Händler, Seriennummer und Fristen eintragen.</small></div></div>
    <div class="intro-step"><span>2</span><div><strong>Unterlagen & Historie sammeln</strong><small>Belege, Reparaturen und Wartungen bleiben beim Produkt gebündelt.</small></div></div>
    <div class="intro-step"><span>3</span><div><strong>QR-Pass teilen oder übergeben</strong><small>Du entscheidest selbst, welche Informationen öffentlich sichtbar sind.</small></div></div>
  </div>
  <div class="intro-trust"><span>🔒</span><div><strong>Privat bleibt privat</strong><small>Die Testversion speichert deine Daten lokal. Öffentliche QR-Daten werden nur aus von dir freigegebenen Feldern erzeugt.</small></div></div>
  <div class="form-actions intro-actions"><button type="button" class="ghost-btn" data-action="close-modal">Später</button><button type="button" class="soft-btn" data-action="load-demo">Demo ansehen</button><button type="button" class="primary-btn" data-action="start-guided">Erstes Produkt anlegen</button></div>`;
}

function maybeShowIntro(){
  if(!state.settings.introSeen){
    state.settings.introSeen = true;
    saveState();
    modal(introModal());
  }
}

function dashboardView() {
  const actions=getActions(); const products=state.products.slice().sort((a,b)=>(b.createdAt||'').localeCompare(a.createdAt||''));
  const historyCount=products.reduce((n,p)=>n+(p.history?.length||0),0);
  const emptyHero=!products.length?`<div class="onboarding"><div class="step"><strong>1. Produkt anlegen</strong><small>Foto, Kaufdaten und Seriennummer.</small></div><div class="step"><strong>2. QR-Pass erzeugen</strong><small>Nur freigegebene Daten werden öffentlich.</small></div><div class="step"><strong>3. Lebenslauf pflegen</strong><small>Service, Reparaturen und Übergabe.</small></div></div>`:'';
  return `<section class="hero"><h1>Deine Dinge. Eine digitale Geschichte.</h1><p>Kaufdaten, Fristen, Dokumente, Wartung, QR-Pass und Übergabe – zunächst komplett lokal unter deiner Kontrolle.</p><div class="hero-row"><button class="primary-btn" data-action="new-product">＋ Produkt hinzufügen</button>${products.length?'<button class="ghost-btn" data-nav="actions">Was ist jetzt wichtig?</button>':'<button class="ghost-btn" data-action="load-demo">Demo laden</button>'}</div>${emptyHero}</section>
  <section class="grid"><div class="card span-4"><div class="muted">Produkte</div><div class="stat">${products.length}</div><div class="muted">${products.filter(p=>p.status==='active').length} aktiv</div></div><div class="card span-4"><div class="muted">Offene Aktionen</div><div class="stat">${actions.length}</div><div class="muted">Fristen & Status</div></div><div class="card span-4"><div class="muted">Historieneinträge</div><div class="stat">${historyCount}</div><div class="muted">Service & Reparaturen</div></div></section>
  <div class="section-title"><h2>Jetzt wichtig</h2><button class="ghost-btn" data-nav="actions">Alle</button></div>${actions.length?`<div class="action-list">${actions.slice(0,4).map(actionRow).join('')}</div>`:'<div class="empty">Keine dringenden Fristen. Das ist gut.</div>'}
  <div class="section-title"><h2>Zuletzt hinzugefügt</h2><button class="ghost-btn" data-nav="products">Alle Produkte</button></div>${products.length?`<div class="product-list">${products.slice(0,5).map(productRow).join('')}</div>`:'<div class="empty"><strong>Noch kein Produkt angelegt.</strong><br>Starte mit einem E-Bike, Werkzeug oder Haushaltsgerät.</div>'}`;
}

function productsView() {
  const products=state.products.slice().sort((a,b)=>productTitle(a).localeCompare(productTitle(b)));
  return `<div class="section-title"><h2>Meine Produkte</h2><button class="primary-btn" data-action="new-product">＋ Hinzufügen</button></div>${products.length?`<div class="product-list">${products.map(productRow).join('')}</div>`:'<div class="empty">Noch keine Produkte vorhanden.</div>'}`;
}

function actionsView() {
  const actions=getActions();
  return `<div class="section-title"><h2>Aktionen</h2><span class="muted">Was Aufmerksamkeit braucht</span></div>${actions.length?`<div class="action-list">${actions.map(actionRow).join('')}</div>`:'<div class="empty">Aktuell gibt es keine offenen Fristen oder Warnungen.</div>'}<div class="card flat-card" style="margin-top:14px"><strong>Das Ziel</strong><p class="muted">PassPilot soll nicht nur Dinge speichern, sondern dir im richtigen Moment sagen, was du mit ihnen tun solltest: zurückgeben, warten, reklamieren, verkaufen oder übergeben.</p></div>`;
}

function backupView() {
  return `<div class="section-title"><h2>Backup & Umzug</h2><span class="muted">Deine Daten gehören dir</span></div><section class="grid"><div class="card span-6"><h3>Vollständiges Backup</h3><p class="muted">Produkte, Historie und lokale Dokumente in eine JSON-Datei exportieren.</p><button class="primary-btn" data-action="export-backup">Backup exportieren</button></div><div class="card span-6"><h3>Wiederherstellen</h3><p class="muted">PassPilot-Backup oder Übergabepaket importieren.</p><label class="ghost-btn" style="display:inline-block">Datei auswählen<input id="backupImport" type="file" accept="application/json,.json" hidden></label></div><div class="card span-12"><h3>Local-first</h3><p class="muted">Diese Testversion hat keinen Benutzeraccount und keine zentrale Datenbank. Deshalb synchronisiert sie noch nicht automatisch zwischen Handy und PC. Das Backup ist die sichere Brücke bis zur späteren Cloud-Version.</p></div></section>`;
}

function productRow(p) {
  const media=p.coverImage?`<img class="product-thumb" src="${esc(p.coverImage)}" alt="">`:`<span class="product-icon">${categoryIcon(p.category)}</span>`;
  return `<button class="product-row" data-action="open-product" data-id="${esc(p.id)}">${media}<span class="product-main"><strong>${esc(productTitle(p))}</strong><small>${esc(categoryLabel(p.category))}${p.serial?` · SN ${esc(p.serial)}`:''}</small></span><span>${statusBadge(p.status)}</span><span class="row-end">›</span></button>`;
}

function actionRow(a) {
  return `<button class="action-row" data-action="open-product" data-id="${esc(a.productId)}"><span class="product-icon">${a.icon}</span><span class="product-main"><strong>${esc(a.title)}</strong><small>${esc(a.detail)}${a.date&&a.date<'9998'?` · ${formatDate(a.date)}`:''}</small></span><span class="badge ${a.kind}">${a.kind==='danger'?'wichtig':a.kind==='warn'?'bald':'Info'}</span><span class="row-end">›</span></button>`;
}

function openProduct(id) {
  const p=getProduct(id); if(!p)return;
  setNav(''); document.getElementById('app').innerHTML=productDetailView(p);
}

function productDetailView(p) {
  const history=(p.history||[]).slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')); const docs=p.documents||[];
  const cover=p.coverImage?`<img class="cover-image" src="${esc(p.coverImage)}" alt="Produktfoto">`:`<div class="detail-icon">${categoryIcon(p.category)}</div>`;
  return `<button class="ghost-btn" data-nav="products" style="margin-bottom:12px">← Produkte</button><section class="card"><div class="detail-head">${cover}<div style="flex:1"><div class="eyebrow">${esc(categoryLabel(p.category))}</div><h1>${esc(productTitle(p))}</h1><div class="muted">${esc([p.brand,p.model].filter(Boolean).join(' · '))}</div><div style="margin-top:8px">${statusBadge(p.status)}</div></div></div><div class="detail-actions"><button class="primary-btn" data-action="assistant" data-id="${esc(p.id)}">Was möchtest du tun?</button><button class="soft-btn" data-action="show-pass" data-id="${esc(p.id)}">▦ QR-Pass</button><button class="soft-btn" data-action="add-history" data-id="${esc(p.id)}">＋ Historie</button><button class="soft-btn" data-action="add-document" data-id="${esc(p.id)}">＋ Dokument</button><button class="ghost-btn" data-action="edit-product" data-id="${esc(p.id)}">Bearbeiten</button><button class="ghost-btn" data-action="transfer-product" data-id="${esc(p.id)}">⇄ Übergabe</button></div></section>
  <section class="grid" style="margin-top:14px"><div class="card span-6"><h3>Kauf & Fristen</h3><div class="kv"><div>Kaufdatum</div><div>${formatDate(p.purchaseDate)}</div><div>Händler</div><div>${esc(p.retailer||'—')}</div><div>Kaufpreis</div><div>${formatMoney(p.price,p.currency)}</div><div>Rückgabe bis</div><div>${formatDate(p.returnUntil)} ${deadlineBadge(p.returnUntil,30)}</div><div>Garantie bis</div><div>${formatDate(p.warrantyUntil)} ${deadlineBadge(p.warrantyUntil,90)}</div><div>Nächste Wartung</div><div>${formatDate(p.nextMaintenance)} ${deadlineBadge(p.nextMaintenance,30)}</div></div></div><div class="card span-6"><h3>Produktidentität</h3><div class="kv"><div>Marke</div><div>${esc(p.brand||'—')}</div><div>Modell</div><div>${esc(p.model||'—')}</div><div>Seriennummer</div><div>${esc(p.serial||'—')}</div><div>Ort</div><div>${esc(p.location||'—')}</div><div>Status</div><div>${statusBadge(p.status)}</div></div><div class="detail-actions"><button class="${p.status==='lost'?'soft-btn':'danger-btn'}" data-action="toggle-lost" data-id="${esc(p.id)}">${p.status==='lost'?'Als gefunden markieren':'🚨 Als verloren markieren'}</button><button class="${p.status==='sale'?'soft-btn':'ghost-btn'}" data-action="toggle-sale" data-id="${esc(p.id)}">${p.status==='sale'?'Verkaufsmodus beenden':'🏷 Zum Verkauf'}</button></div></div>${p.notes?`<div class="card span-12"><h3>Private Notiz</h3><p>${esc(p.notes).replaceAll('\n','<br>')}</p></div>`:''}</section>
  <div class="section-title"><h2>Lebenslauf</h2><button class="soft-btn" data-action="add-history" data-id="${esc(p.id)}">＋ Eintrag</button></div>${history.length?`<div class="timeline">${history.map(historyRow).join('')}</div>`:'<div class="empty">Noch keine Historie.</div>'}
  <div class="section-title"><h2>Dokumente</h2><button class="soft-btn" data-action="add-document" data-id="${esc(p.id)}">＋ Datei</button></div>${docs.length?`<div class="product-list">${docs.map(d=>documentRow(p.id,d)).join('')}</div>`:'<div class="empty">Noch keine lokalen Dokumente hinterlegt.</div>'}
  <div class="danger-zone"><button class="danger-link" data-action="delete-product" data-id="${esc(p.id)}">Produkt vollständig löschen</button></div>`;
}

function historyRow(h) {
  const icons={purchase:'🛒',service:'🔧',repair:'🧰',maintenance:'🧼',note:'📝',transfer:'⇄'};
  return `<div class="timeline-item"><div class="timeline-dot"></div><div class="timeline-body"><strong>${icons[h.type]||'•'} ${esc(h.title||'Eintrag')}</strong><small>${formatDate(h.date)} · ${h.public?'im öffentlichen Pass':'privat'}</small>${h.details?`<p>${esc(h.details).replaceAll('\n','<br>')}</p>`:''}</div></div>`;
}

function documentRow(productId,d) {
  return `<div class="document-row"><div class="product-main"><strong>${esc(d.name)}</strong><small>${esc(d.category||'Dokument')} · ${formatBytes(d.size)} · ${d.share?'übergabefähig':'privat'}</small></div><div class="doc-actions"><button class="ghost-btn" data-action="open-document" data-product-id="${esc(productId)}" data-doc-id="${esc(d.id)}">Öffnen</button><button class="danger-btn" data-action="delete-document" data-product-id="${esc(productId)}" data-doc-id="${esc(d.id)}">×</button></div></div>`;
}

function formatBytes(bytes=0){ if(bytes<1024)return`${bytes} B`; if(bytes<1048576)return`${(bytes/1024).toFixed(1)} KB`; return`${(bytes/1048576).toFixed(1)} MB`; }

function productForm(p={}) {
  const edit=Boolean(p.id);
  return `<div class="modal-head"><h2>${edit?'Produkt bearbeiten':'Produkt hinzufügen'}</h2><button class="icon-btn" data-action="close-modal">✕</button></div><form id="productForm" data-id="${esc(p.id||'')}"><div class="form-grid"><div class="field full"><label>Produktfoto</label><input type="file" name="coverPhoto" accept="image/*" capture="environment"><small class="muted">Optional. Wird verkleinert und lokal gespeichert.</small></div><div class="field"><label>Kategorie</label><select name="category">${Object.entries(categoryMeta).map(([k,v])=>`<option value="${k}" ${p.category===k?'selected':''}>${v[1]} ${v[0]}</option>`).join('')}</select></div><div class="field"><label>Eigener Name</label><input name="name" value="${esc(p.name||'')}" placeholder="z. B. Mein E-Bike"></div><div class="field"><label>Marke</label><input name="brand" value="${esc(p.brand||'')}" placeholder="Cube"></div><div class="field"><label>Modell</label><input name="model" value="${esc(p.model||'')}" placeholder="Kathmandu Hybrid"></div><div class="field"><label>Serien-/Rahmennummer</label><input name="serial" value="${esc(p.serial||'')}"></div><div class="field"><label>Standort / Zuordnung</label><input name="location" value="${esc(p.location||'')}" placeholder="Garage, Büro …"></div><div class="field"><label>Kaufdatum</label><input type="date" name="purchaseDate" value="${esc(p.purchaseDate||'')}"></div><div class="field"><label>Händler</label><input name="retailer" value="${esc(p.retailer||'')}"></div><div class="field"><label>Kaufpreis</label><input type="number" min="0" step="0.01" name="price" value="${esc(p.price??'')}"></div><div class="field"><label>Währung</label><select name="currency"><option ${p.currency!=='USD'?'selected':''}>EUR</option><option ${p.currency==='USD'?'selected':''}>USD</option></select></div><div class="field"><label>Rückgabe möglich bis</label><input type="date" name="returnUntil" value="${esc(p.returnUntil||'')}"></div><div class="field"><label>Garantie / Zusage bis</label><input type="date" name="warrantyUntil" value="${esc(p.warrantyUntil||'')}"></div><div class="field"><label>Nächste Wartung</label><input type="date" name="nextMaintenance" value="${esc(p.nextMaintenance||'')}"></div><div class="field full"><label>Private Notiz</label><textarea name="notes">${esc(p.notes||'')}</textarea></div><div class="field full"><label>Öffentlicher Pass-Hinweis</label><textarea name="publicNote" maxlength="180" placeholder="z. B. Original-Ladegerät vorhanden">${esc(p.publicNote||'')}</textarea></div><div class="field full"><label>Im QR-Pass freigeben</label><label class="checkbox-row"><input type="checkbox" name="shareSerial" ${p.publicSettings?.serial!==false?'checked':''}> Seriennummer / Rahmennummer</label><label class="checkbox-row"><input type="checkbox" name="sharePurchaseDate" ${p.publicSettings?.purchaseDate?'checked':''}> Kaufdatum</label></div></div><div class="form-actions"><button type="button" class="ghost-btn" data-action="close-modal">Abbrechen</button><button class="primary-btn">${edit?'Speichern':'Produkt anlegen'}</button></div></form>`;
}

function historyForm(id) {
  return `<div class="modal-head"><h2>Historie hinzufügen</h2><button class="icon-btn" data-action="close-modal">✕</button></div><form id="historyForm" data-id="${esc(id)}"><div class="form-grid"><div class="field"><label>Art</label><select name="type"><option value="service">🔧 Service</option><option value="repair">🧰 Reparatur</option><option value="maintenance">🧼 Wartung/Pflege</option><option value="purchase">🛒 Kauf</option><option value="note">📝 Notiz</option><option value="transfer">⇄ Übergabe</option></select></div><div class="field"><label>Datum</label><input type="date" name="date" value="${new Date().toISOString().slice(0,10)}"></div><div class="field full"><label>Titel</label><input required name="title" placeholder="z. B. Jahresinspektion"></div><div class="field full"><label>Details</label><textarea name="details"></textarea></div><div class="field full"><label class="checkbox-row"><input type="checkbox" name="public"> Im öffentlichen QR-Pass und bei Übergabe zeigen</label></div></div><div class="form-actions"><button type="button" class="ghost-btn" data-action="close-modal">Abbrechen</button><button class="primary-btn">Eintrag speichern</button></div></form>`;
}

function documentForm(id) {
  return `<div class="modal-head"><h2>Dokument lokal speichern</h2><button class="icon-btn" data-action="close-modal">✕</button></div><form id="documentForm" data-id="${esc(id)}"><div class="form-grid"><div class="field full"><label>Datei</label><input required type="file" name="file" accept="image/*,.pdf,.txt,.doc,.docx"></div><div class="field full"><label>Kategorie</label><select name="category"><option>Rechnung</option><option>Garantie</option><option>Bedienungsanleitung</option><option>Servicebeleg</option><option>Foto</option><option>Sonstiges</option></select></div><div class="field full"><label class="checkbox-row"><input type="checkbox" name="share"> Bei digitaler Übergabe mitgeben</label></div></div><div class="card flat-card" style="margin-top:12px"><small class="muted">Die Datei bleibt in dieser Testversion lokal im Browser.</small></div><div class="form-actions"><button type="button" class="ghost-btn" data-action="close-modal">Abbrechen</button><button class="primary-btn">Speichern</button></div></form>`;
}

function settingsForm() {
  const install=deferredInstallPrompt?'<button type="button" class="soft-btn" data-action="install-app">App installieren</button>':'<span class="muted">Im Browser „Zum Home-Bildschirm“ bzw. „App installieren“ wählen.</span>';
  return `<div class="modal-head"><h2>Einstellungen</h2><button class="icon-btn" data-action="close-modal">✕</button></div><form id="settingsForm"><div class="form-grid"><div class="field full"><label>Name / Alias (optional)</label><input name="ownerAlias" value="${esc(state.settings.ownerAlias||'')}"></div><div class="field full"><label>Öffentliche Basis-URL</label><input name="publicBaseUrl" value="${esc(state.settings.publicBaseUrl||'')}" placeholder="https://deinname.web.app/"></div></div><div class="card flat-card" style="margin-top:12px"><strong>App-Installation</strong><div style="margin-top:8px">${install}</div></div><div class="card flat-card" style="margin-top:12px"><strong>Hilfe & Testen</strong><div class="detail-actions" style="margin-top:10px"><button type="button" class="soft-btn" data-action="intro">Einführung öffnen</button>${state.settings.demoMode?'<button type="button" class="ghost-btn" data-action="exit-demo">Demo beenden</button>':'<button type="button" class="ghost-btn" data-action="load-demo">Demo laden</button>'}</div></div><div class="card flat-card" style="margin-top:12px"><strong>App zurücksetzen</strong><p class="muted" style="margin:8px 0 10px">Löscht alle lokalen Produkte, Dateien und Einstellungen von diesem Gerät.</p><button type="button" class="danger-btn" data-action="reset-app">App komplett zurücksetzen</button></div><div class="card flat-card" style="margin-top:12px"><small class="muted">Version ${APP_VERSION}. Private Daten liegen lokal. Für öffentlich scanbare QR-Pässe muss die statische App einmal über HTTPS gehostet werden.</small></div><div class="form-actions"><button type="button" class="ghost-btn" data-action="close-modal">Abbrechen</button><button class="primary-btn">Speichern</button></div></form>`;
}

function clean(v,max){return String(v||'').slice(0,max)}
function publicSnapshot(p) {
  return {v:1,id:clean(p.id,70),title:clean(productTitle(p),80),category:clean(p.category,20),brand:clean(p.brand,50),model:clean(p.model,70),serial:p.publicSettings?.serial===false?'':clean(p.serial,70),purchaseDate:p.publicSettings?.purchaseDate?clean(p.purchaseDate,10):'',status:clean(p.status||'active',12),publicNote:clean(p.publicNote,120),history:(p.history||[]).filter(h=>h.public).slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,5).map(h=>({date:clean(h.date,10),type:clean(h.type,14),title:clean(h.title,60),details:clean(h.details,80)}))};
}

function encodeSnapshot(obj){const bytes=new TextEncoder().encode(JSON.stringify(obj));let bin='';bytes.forEach(b=>bin+=String.fromCharCode(b));return btoa(bin).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');}
function decodeSnapshot(encoded){try{let n=encoded.replaceAll('-','+').replaceAll('_','/');while(n.length%4)n+='=';const bin=atob(n);return JSON.parse(new TextDecoder().decode(Uint8Array.from(bin,c=>c.charCodeAt(0))));}catch{return null}}
function getBaseUrl(){const configured=(state.settings.publicBaseUrl||'').trim();if(configured)return configured.split('#')[0];if(location.protocol==='http:'||location.protocol==='https:')return`${location.origin}${location.pathname}`;return''}
function publicUrlForProduct(p){const base=getBaseUrl();return base?`${base}#pass=${encodeSnapshot(publicSnapshot(p))}`:''}

function showPassModal(id) {
  const p=getProduct(id); if(!p)return; const encoded=encodeSnapshot(publicSnapshot(p)); const url=publicUrlForProduct(p);
  modal(`<div class="modal-head"><h2>QR-Produktpass</h2><button class="icon-btn" data-action="close-modal">✕</button></div><div class="qr-box"><div id="qrcode"></div><strong>${esc(productTitle(p))}</strong><span class="muted">Nur freigegebene Daten befinden sich im Pass.</span></div>${url?`<div class="field" style="margin-top:12px"><label>Öffentlicher Link</label><div class="code">${esc(url)}</div></div>`:'<div class="pass-banner sale" style="margin-top:12px"><strong>Noch nicht öffentlich scanbar.</strong><br>Hoste die App einmal über HTTPS und trage die Adresse in den Einstellungen ein.</div>'}<div class="form-actions"><button class="ghost-btn" data-action="preview-pass" data-payload="${esc(encoded)}">Vorschau</button>${url?`<button class="ghost-btn" data-action="print-label" data-id="${esc(id)}">QR-Etikett drucken</button><button class="ghost-btn" data-action="share-pass" data-id="${esc(id)}">Teilen</button><button class="primary-btn" data-action="copy-pass-url" data-url="${esc(url)}">Link kopieren</button>`:''}</div>`);
  setTimeout(()=>{const el=document.getElementById('qrcode');if(!el)return;if(url&&window.PassPilotQR){try{window.PassPilotQR.renderToCanvas(url,el,220)}catch(err){console.error(err);el.innerHTML='<div class="muted">QR-Daten sind zu groß. Kürze freigegebene Historie oder Hinweise.</div>'}}else el.innerHTML='<div class="muted" style="padding:36px 10px;text-align:center">QR erscheint nach Angabe einer öffentlichen HTTPS-Adresse.</div>';},0);
}

function renderPublicPass(encoded) {
  const data=decodeSnapshot(encoded); setNav(''); const app=document.getElementById('app');
  if(!data){app.innerHTML='<div class="pass-view"><div class="card"><h2>Ungültiger Produktpass</h2><p class="muted">Der Link konnte nicht gelesen werden.</p><button class="primary-btn" data-action="exit-pass">Zur App</button></div></div>';return}
  const history=Array.isArray(data.history)?data.history:[];
  app.innerHTML=`<div class="pass-view">${data.status==='lost'?'<div class="pass-banner lost"><strong>🚨 Dieser Gegenstand ist als verloren markiert.</strong></div>':''}${data.status==='sale'?'<div class="pass-banner sale"><strong>🏷 Dieser Gegenstand ist als zum Verkauf markiert.</strong></div>':''}<section class="card"><div class="detail-head"><div class="detail-icon">${categoryIcon(data.category)}</div><div><div class="eyebrow">Digitaler Produktpass</div><h1>${esc(data.title||'Produkt')}</h1><div class="muted">${esc([data.brand,data.model].filter(Boolean).join(' · '))}</div></div></div><div class="kv" style="margin-top:18px"><div>Kategorie</div><div>${esc(categoryLabel(data.category))}</div>${data.serial?`<div>Seriennummer</div><div>${esc(data.serial)}</div>`:''}${data.purchaseDate?`<div>Kaufdatum</div><div>${formatDate(data.purchaseDate)}</div>`:''}<div>Status</div><div>${statusBadge(data.status)}</div></div>${data.publicNote?`<div class="card flat-card" style="margin-top:14px"><strong>Hinweis</strong><p>${esc(data.publicNote)}</p></div>`:''}</section><div class="section-title"><h2>Freigegebene Historie</h2></div>${history.length?`<div class="timeline">${history.sort((a,b)=>(b.date||'').localeCompare(a.date||'')).map(historyRow).join('')}</div>`:'<div class="empty">Noch keine Historie freigegeben.</div>'}<div class="card flat-card" style="margin-top:14px"><small class="muted">Dieser Pass ist in dieser Testversion ein nutzergenerierter Nachweis und keine amtliche Eigentums-, Echtheits- oder EU-DPP-Verifikation.</small></div><button class="ghost-btn" data-action="exit-pass" style="margin-top:12px">PassPilot öffnen</button></div>`;
}

function assistantModal(id) {
  const p=getProduct(id);if(!p)return;
  modal(`<div class="modal-head"><h2>Was möchtest du tun?</h2><button class="icon-btn" data-action="close-modal">✕</button></div><p class="muted">${esc(productTitle(p))}</p><div class="assistant-grid"><button class="assistant-card" data-action="claim-product" data-id="${esc(id)}"><span>⚠️</span><strong>Problem / Reklamation</strong><small>Fehler erfassen und Vorgang vorbereiten</small></button><button class="assistant-card" data-action="add-history" data-id="${esc(id)}"><span>🔧</span><strong>Service eintragen</strong><small>Wartung oder Reparatur dokumentieren</small></button><button class="assistant-card" data-action="toggle-sale" data-id="${esc(id)}"><span>🏷</span><strong>${p.status==='sale'?'Verkaufsmodus beenden':'Verkaufen'}</strong><small>Pass als Nachweis nutzen</small></button><button class="assistant-card" data-action="transfer-product" data-id="${esc(id)}"><span>⇄</span><strong>Übergeben</strong><small>Freigegebene Akte exportieren</small></button><button class="assistant-card" data-action="show-pass" data-id="${esc(id)}"><span>▦</span><strong>QR-Pass</strong><small>Zeigen, teilen oder Etikett drucken</small></button><button class="assistant-card danger-assistant" data-action="toggle-lost" data-id="${esc(id)}"><span>🚨</span><strong>${p.status==='lost'?'Als gefunden markieren':'Verloren melden'}</strong><small>Status im QR-Pass ändern</small></button></div>`);
}

function claimModal(id) {
  const p=getProduct(id);if(!p)return;
  modal(`<div class="modal-head"><h2>Problem / Reklamation</h2><button class="icon-btn" data-action="close-modal">✕</button></div><form id="claimForm" data-id="${esc(id)}"><div class="form-grid"><div class="field full"><label>Was ist passiert?</label><textarea required name="issue" placeholder="z. B. Gerät lädt seit heute nicht mehr."></textarea></div><div class="field"><label>Problem seit</label><input type="date" name="since" value="${new Date().toISOString().slice(0,10)}"></div><div class="field"><label>Gewünschte Lösung</label><select name="wish"><option>Prüfung / Reparatur</option><option>Ersatz</option><option>Rückgabe / Erstattung prüfen</option><option>Kontaktaufnahme</option></select></div></div><div class="card flat-card" style="margin-top:12px"><small class="muted">Die App entscheidet nicht, ob ein rechtlicher Anspruch besteht. Sie stellt nur deine vorhandenen Daten zusammen.</small></div><div class="form-actions"><button type="button" class="ghost-btn" data-action="close-modal">Abbrechen</button><button class="primary-btn">Vorgang vorbereiten</button></div></form>`);
}

function claimResultModal(p,issue,since,wish) {
  const text=`Betreff: Problem mit ${productTitle(p)}\n\nProdukt: ${productTitle(p)}\nMarke/Modell: ${[p.brand,p.model].filter(Boolean).join(' / ')||'—'}\nSeriennummer: ${p.serial||'—'}\nKaufdatum: ${p.purchaseDate||'—'}\nHändler: ${p.retailer||'—'}\nProblem seit: ${since||'—'}\n\nFehlerbeschreibung:\n${issue}\n\nGewünschte Lösung: ${wish}\n\nKaufbeleg und weitere Unterlagen können bei Bedarf beigefügt werden.`;
  modal(`<div class="modal-head"><h2>Vorgang vorbereitet</h2><button class="icon-btn" data-action="close-modal">✕</button></div><p class="muted">Diesen Text kannst du an Händler, Hersteller oder Werkstatt weitergeben.</p><textarea id="claimText" class="claim-text" readonly>${esc(text)}</textarea><div class="form-actions"><button class="ghost-btn" data-action="save-claim-history" data-id="${esc(p.id)}" data-issue="${esc(issue)}">In Historie speichern</button><button class="primary-btn" data-action="copy-claim">Text kopieren</button></div>`);
}

function openTransferModal(id) {
  const p=getProduct(id);if(!p)return;
  modal(`<div class="modal-head"><h2>Digitale Übergabe</h2><button class="icon-btn" data-action="close-modal">✕</button></div><p><strong>${esc(productTitle(p))}</strong> kann als Übergabepaket exportiert werden.</p><div class="card flat-card"><strong>Mitgegeben werden</strong><p class="muted">Produktdaten, öffentlich markierte Historie und Dokumente mit aktivierter Übergabefreigabe.</p><strong>Nicht mitgegeben werden</strong><p class="muted">Private Notizen, Händler, Kaufpreis und nicht freigegebene Dokumente.</p></div><div class="form-actions"><label class="ghost-btn">Paket übernehmen<input id="transferImport" type="file" accept="application/json,.json" hidden></label><button class="primary-btn" data-action="export-transfer" data-id="${esc(id)}">Übergabepaket erstellen</button></div>`);
}

async function compressImage(file,maxSide=900,quality=.82) {
  if(!(file instanceof File)||!file.type.startsWith('image/'))return''; const data=await blobToDataUrl(file); const img=new Image();
  await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=data}); const scale=Math.min(1,maxSide/Math.max(img.width,img.height));
  const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);return c.toDataURL('image/jpeg',quality);
}

async function copyText(value){try{await navigator.clipboard.writeText(value)}catch{const t=document.createElement('textarea');t.value=value;document.body.appendChild(t);t.select();document.execCommand('copy');t.remove()}}

function printLabel(id) {
  const p=getProduct(id);if(!p)return;const url=publicUrlForProduct(p);if(!url)return toast('Öffentliche Basis-URL fehlt');let data='';
  try{data=window.PassPilotQR?.toDataUrl(url,520)||''}catch(err){console.error(err)} if(!data)return toast('QR-Code konnte nicht erstellt werden');
  const w=window.open('','_blank','width=620,height=760');if(!w)return toast('Pop-up wurde blockiert');
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>PassPilot Etikett</title><style>body{font-family:system-ui;margin:0;display:grid;place-items:center;min-height:100vh}.label{width:320px;text-align:center;border:1px solid #777;border-radius:16px;padding:22px}.label img{width:240px}.brand{font-weight:850}.title{font-size:18px;font-weight:750;margin-top:8px}.small{font-size:11px;color:#555;margin-top:8px}</style></head><body><div class="label"><div class="brand">PassPilot</div><img src="${data}"><div class="title">${esc(productTitle(p))}</div><div class="small">Scannen für den digitalen Produktpass</div></div><script>setTimeout(()=>window.print(),300)<\/script></body></html>`);w.document.close();
}

async function sharePass(id) {
  const p=getProduct(id);if(!p)return;const url=publicUrlForProduct(p);if(!url)return toast('Öffentliche Basis-URL fehlt');
  if(navigator.share){try{await navigator.share({title:`Produktpass – ${productTitle(p)}`,text:'Digitaler Produktpass',url});return}catch(err){if(err?.name==='AbortError')return}}
  await copyText(url);toast('Pass-Link kopiert');
}

async function exportTransfer(id) {
  const p=getProduct(id);if(!p)return;const files=await getProductFiles(id,true);
  const transfer={...p,id:uid('prod'),notes:'',price:'',retailer:'',returnUntil:'',status:'active',coverImage:p.coverImage||'',history:(p.history||[]).filter(h=>h.public).concat([{id:uid('hist'),date:new Date().toISOString().slice(0,10),type:'transfer',title:'Digital übergeben',details:'Produktpass wurde als Übergabepaket exportiert.',public:true}]),documents:(p.documents||[]).filter(d=>d.share)};
  downloadJson({format:'passpilot-transfer',version:2,createdAt:new Date().toISOString(),product:transfer,files},`PassPilot-Uebergabe-${safeFilename(productTitle(p))}.json`);toast('Übergabepaket erstellt');
}

async function exportBackup() {
  toast('Backup wird erstellt …');const files=[];for(const p of state.products)files.push(...await getProductFiles(p.id,false));downloadJson({format:'passpilot-backup',version:2,appVersion:APP_VERSION,createdAt:new Date().toISOString(),state,files},`PassPilot-Backup-${new Date().toISOString().slice(0,10)}.json`);toast('Backup gespeichert');
}

function downloadJson(data,filename){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function safeFilename(name){return String(name||'Produkt').replace(/[^a-z0-9äöüß_-]+/gi,'_').slice(0,60)}

async function importPayload(payload) {
  if(payload?.format==='passpilot-backup'&&payload.state){
    const idMap=new Map();for(const source of payload.state.products||[]){const p=normalizeProduct(structuredClone(source));const old=p.id;if(state.products.some(x=>x.id===p.id))p.id=uid('prod');idMap.set(old,p.id);state.products.push(p)}
    state.settings={...state.settings,...(payload.state.settings||{})};saveState();
    for(const row of payload.files||[]){const target=idMap.get(row.productId)||state.products.find(p=>p.documents?.some(d=>d.id===row.doc?.id))?.id;if(target&&row.data)await putFile(target,row.doc.id,dataUrlToBlob(row.data))}
    toast('Backup importiert');render();return;
  }
  if(payload?.format==='passpilot-transfer'&&payload.product){const p=normalizeProduct(payload.product);p.id=uid('prod');p.createdAt=new Date().toISOString();state.products.push(p);saveState();for(const row of payload.files||[])if(row.data)await putFile(p.id,row.doc.id,dataUrlToBlob(row.data));toast('Übergabe übernommen');closeModal();currentView='products';render();openProduct(p.id);return}
  throw new Error('Unbekanntes Dateiformat');
}

async function clearIndexedDb(){
  return new Promise((resolve)=>{
    const req=indexedDB.deleteDatabase(DB_NAME);
    req.onsuccess=()=>resolve(true); req.onerror=()=>resolve(false); req.onblocked=()=>resolve(false);
  });
}

async function resetApp(){
  if(!confirm('Wirklich alle lokalen PassPilot-Daten auf diesem Gerät löschen?')) return;
  localStorage.removeItem(STORAGE_KEY);
  localStorage.removeItem(LEGACY_STORAGE_KEY);
  await clearIndexedDb();
  toast('App wird zurückgesetzt');
  setTimeout(()=>location.reload(), 350);
}

function exitDemo(){
  const hadDemo = state.products.some(p=>p.isDemo);
  state.products = state.products.filter(p=>!p.isDemo);
  state.settings.demoMode = false;
  saveState();
  closeModal();
  currentView='dashboard';
  render();
  toast(hadDemo ? 'Demo beendet' : 'Keine Demo-Daten vorhanden');
}

function loadDemo() {
  state.products = state.products.filter(p=>!p.isDemo);
  const now=new Date();const iso=d=>d.toISOString().slice(0,10);const add=n=>{const d=new Date(now);d.setDate(d.getDate()+n);return iso(d)};
  state.settings.demoMode = true;
  state.products.push(normalizeProduct({id:uid('prod'),createdAt:new Date().toISOString(),category:'ebike',name:'Mein E-Bike',brand:'Cube',model:'Kathmandu Hybrid',serial:'DEMO-RN-2026-4815',location:'Garage',purchaseDate:add(-120),retailer:'Demo Fahrradhaus',price:3999,currency:'EUR',warrantyUntil:add(50),nextMaintenance:add(18),publicNote:'Original-Ladegerät vorhanden. Servicehistorie dokumentiert.',status:'active',publicSettings:{serial:true,purchaseDate:false},history:[{id:uid('hist'),date:add(-120),type:'purchase',title:'Kauf',details:'Neu gekauft.',public:false},{id:uid('hist'),date:add(-70),type:'service',title:'Erstinspektion',details:'Bremsen, Antrieb und Software geprüft.',public:true}],documents:[],isDemo:true}));
  state.products.push(normalizeProduct({id:uid('prod'),createdAt:new Date(Date.now()-1000).toISOString(),category:'electronics',name:'Noise-Cancelling Kopfhörer',brand:'Sony',model:'WH-Serie',purchaseDate:add(-10),retailer:'Demo Shop',price:299,currency:'EUR',returnUntil:add(4),warrantyUntil:add(720),publicSettings:{serial:false,purchaseDate:false},isDemo:true}));
  saveState();closeModal();currentView='dashboard';render();toast('Demo geladen');
}

async function installApp(){if(!deferredInstallPrompt)return toast('Nutze im Browser „Zum Home-Bildschirm“ / „App installieren“');deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;closeModal()}

async function handleClick(e) {
  const el=e.target.closest('[data-action],[data-nav]');if(!el)return;
  if(el.dataset.nav){currentView=el.dataset.nav;location.hash='';render();return}
  const action=el.dataset.action;const id=el.dataset.id;
  if(action==='home'){currentView='dashboard';location.hash='';render()}
  else if(action==='new-product')modal(productForm());
  else if(action==='edit-product')modal(productForm(getProduct(id)));
  else if(action==='open-product')openProduct(id);
  else if(action==='add-history')modal(historyForm(id));
  else if(action==='add-document')modal(documentForm(id));
  else if(action==='close-modal')closeModal();
  else if(action==='settings')modal(settingsForm());
  else if(action==='intro')modal(introModal());
  else if(action==='start-guided'){closeModal();modal(productForm());}
  else if(action==='exit-demo')exitDemo();
  else if(action==='reset-app')await resetApp();
  else if(action==='assistant')assistantModal(id);
  else if(action==='claim-product')claimModal(id);
  else if(action==='show-pass')showPassModal(id);
  else if(action==='preview-pass'){closeModal();location.hash=`pass=${el.dataset.payload}`}
  else if(action==='exit-pass'){location.hash='';currentView='dashboard';render()}
  else if(action==='copy-pass-url'){await copyText(el.dataset.url);toast('Link kopiert')}
  else if(action==='print-label')printLabel(id);
  else if(action==='share-pass')await sharePass(id);
  else if(action==='transfer-product')openTransferModal(id);
  else if(action==='export-transfer')await exportTransfer(id);
  else if(action==='export-backup')await exportBackup();
  else if(action==='load-demo')loadDemo();
  else if(action==='install-app')await installApp();
  else if(action==='copy-claim'){await copyText(document.getElementById('claimText')?.value||'');toast('Text kopiert')}
  else if(action==='save-claim-history'){const p=getProduct(id);if(p){p.history.push({id:uid('hist'),date:new Date().toISOString().slice(0,10),type:'note',title:'Problem / Reklamation vorbereitet',details:el.dataset.issue||'',public:false});saveState();closeModal();openProduct(id);toast('In Historie gespeichert')}}
  else if(action==='toggle-lost'){const p=getProduct(id);if(!p)return;p.status=p.status==='lost'?'active':'lost';saveState();closeModal();openProduct(id);toast(p.status==='lost'?'Als verloren markiert':'Status zurückgesetzt')}
  else if(action==='toggle-sale'){const p=getProduct(id);if(!p)return;p.status=p.status==='sale'?'active':'sale';saveState();closeModal();openProduct(id);toast(p.status==='sale'?'Verkaufsmodus aktiv':'Verkaufsmodus beendet')}
  else if(action==='open-document'){const blob=await getFile(el.dataset.productId,el.dataset.docId);if(!blob)return toast('Datei nicht gefunden');const url=URL.createObjectURL(blob);window.open(url,'_blank','noopener');setTimeout(()=>URL.revokeObjectURL(url),60000)}
  else if(action==='delete-document'){const p=getProduct(el.dataset.productId);if(!p)return;const doc=p.documents.find(d=>d.id===el.dataset.docId);if(!doc)return;if(confirm(`„${doc.name}“ wirklich löschen?`)){p.documents=p.documents.filter(d=>d.id!==doc.id);saveState();await deleteFile(p.id,doc.id);openProduct(p.id);toast('Dokument gelöscht')}}
  else if(action==='delete-product'){const p=getProduct(id);if(p&&confirm(`„${productTitle(p)}“ samt lokalen Dokumenten wirklich löschen?`)){for(const d of p.documents)await deleteFile(p.id,d.id);state.products=state.products.filter(x=>x.id!==id);saveState();currentView='products';render();toast('Produkt gelöscht')}}
}

async function handleSubmit(e) {
  const form=e.target;if(!(form instanceof HTMLFormElement))return;e.preventDefault();const fd=new FormData(form);
  if(form.id==='productForm'){
    const existing=form.dataset.id?getProduct(form.dataset.id):null;const p=existing||normalizeProduct({id:uid('prod'),createdAt:new Date().toISOString()});
    Object.assign(p,{category:fd.get('category'),name:fd.get('name').trim(),brand:fd.get('brand').trim(),model:fd.get('model').trim(),serial:fd.get('serial').trim(),location:fd.get('location').trim(),purchaseDate:fd.get('purchaseDate'),retailer:fd.get('retailer').trim(),price:fd.get('price'),currency:fd.get('currency')||'EUR',returnUntil:fd.get('returnUntil'),warrantyUntil:fd.get('warrantyUntil'),nextMaintenance:fd.get('nextMaintenance'),notes:fd.get('notes').trim(),publicNote:fd.get('publicNote').trim(),publicSettings:{serial:fd.get('shareSerial')==='on',purchaseDate:fd.get('sharePurchaseDate')==='on'}});
    const cover=fd.get('coverPhoto');if(cover instanceof File&&cover.size){try{p.coverImage=await compressImage(cover)}catch(err){console.warn(err);toast('Foto konnte nicht verarbeitet werden')}}
    if(!existing){p.history.push({id:uid('hist'),date:p.purchaseDate||new Date().toISOString().slice(0,10),type:'purchase',title:'Produkt angelegt',details:p.purchaseDate?'Kaufdatum hinterlegt.':'',public:false});state.products.push(p)}
    saveState();closeModal();currentView='products';render();openProduct(p.id);toast(existing?'Gespeichert':'Produkt angelegt');
  } else if(form.id==='historyForm'){
    const p=getProduct(form.dataset.id);if(!p)return;p.history.push({id:uid('hist'),type:fd.get('type'),date:fd.get('date'),title:fd.get('title').trim(),details:fd.get('details').trim(),public:fd.get('public')==='on'});saveState();closeModal();openProduct(p.id);toast('Historie gespeichert');
  } else if(form.id==='documentForm'){
    const p=getProduct(form.dataset.id);if(!p)return;const file=fd.get('file');if(!(file instanceof File)||!file.size)return toast('Bitte Datei auswählen');if(file.size>15*1024*1024&&!confirm('Die Datei ist größer als 15 MB und kann viel lokalen Speicher verbrauchen. Trotzdem speichern?'))return;const doc={id:uid('doc'),name:file.name,type:file.type,size:file.size,category:fd.get('category'),share:fd.get('share')==='on',createdAt:new Date().toISOString()};await putFile(p.id,doc.id,file);p.documents.push(doc);saveState();closeModal();openProduct(p.id);toast('Dokument gespeichert');
  } else if(form.id==='settingsForm'){
    state.settings.ownerAlias=fd.get('ownerAlias').trim();state.settings.publicBaseUrl=fd.get('publicBaseUrl').trim();saveState();closeModal();toast('Einstellungen gespeichert');
  } else if(form.id==='claimForm'){
    const p=getProduct(form.dataset.id);if(!p)return;claimResultModal(p,fd.get('issue').trim(),fd.get('since'),fd.get('wish'));
  }
}

async function handleChange(e){if(e.target.id==='backupImport'||e.target.id==='transferImport'){const file=e.target.files?.[0];if(!file)return;try{await importPayload(JSON.parse(await file.text()));closeModal()}catch(err){console.error(err);toast('Import fehlgeschlagen')}}}

document.addEventListener('click',handleClick);document.addEventListener('submit',handleSubmit);document.addEventListener('change',handleChange);window.addEventListener('hashchange',render);
document.getElementById('modal').addEventListener('click',e=>{if(e.target===e.currentTarget)closeModal()});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e});window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;toast('PassPilot wurde installiert')});
if('serviceWorker'in navigator&&(location.protocol==='http:'||location.protocol==='https:'))navigator.serviceWorker.register('./sw.js').catch(err=>console.warn('Service Worker:',err));
saveState();render();maybeShowIntro();
