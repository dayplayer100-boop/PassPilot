# PassPilot Android App

Dies ist die native Android-Hülle für PassPilot 1.0 Test.

## Was enthalten ist
- komplette PassPilot-Web-App offline im APK
- lokale Datenspeicherung im Android WebView
- Kamera- und Datei-Auswahl für Fotos/PDFs
- QR-Pässe, Fristen, Historie, Übergabe und Backups aus der bestehenden App
- kein Server und kein Account nötig

## Automatischer APK-Build mit GitHub Actions
1. Projekt in ein GitHub-Repository hochladen.
2. Reiter **Actions** öffnen.
3. Workflow **Build PassPilot APK** starten (oder einmal auf `main` pushen).
4. Nach erfolgreichem Build unter **Artifacts** `PassPilot-Android-APK` herunterladen.
5. Enthaltene `PassPilot-1.0-Test.apk` auf Android installieren.

Android kann beim direkten Installieren nach Erlaubnis für „Unbekannte Apps installieren“ fragen.

## Hinweis
Das erzeugte APK ist ein Debug/Test-Build. Für Google Play wird später ein eigener Release-Key und ein signierter Release-Build benötigt.
